package com.bean.demo.exception;

public class UserDataAlreadyAvailableFoundException extends Exception{

	public UserDataAlreadyAvailableFoundException(String message) {
		super(message);
	}

}
