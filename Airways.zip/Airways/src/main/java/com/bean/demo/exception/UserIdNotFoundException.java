package com.bean.demo.exception;

public class UserIdNotFoundException extends Exception {

	public UserIdNotFoundException(String message) {
		super(message);
	}

}
