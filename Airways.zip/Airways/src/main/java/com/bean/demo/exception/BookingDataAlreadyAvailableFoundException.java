package com.bean.demo.exception;

public class BookingDataAlreadyAvailableFoundException extends Exception{
	public BookingDataAlreadyAvailableFoundException(String message) {
		super(message);
	}

}
